## 超分-生成更高分辨率的图片

> 请不要再小内存机器上运行，容易因爆内存而被kill

### 食用方法

安装依赖：

```shell
pip install basicsr realesrgan
```

欢迎 pr，因爆内存而被 kill 的问题有待解决

### 更新

**2022/04/09**

1. 真寻beta2适配